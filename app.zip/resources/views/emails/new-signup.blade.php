<img src="{{ asset('softlinkexpress_logo.png') }}" width="120">

<h3>Hello {{ $name }}</h3>

<p>Thank you for signing up to our platform<br>
    This will enable us generate your parcel tracking code.<br>
    You will be contacted by our staff to provide you with your tracking code.
</p><br><br>

<p align="center">
   For more info, contact <i>info@softlinkexpress.com</i>
</p>
