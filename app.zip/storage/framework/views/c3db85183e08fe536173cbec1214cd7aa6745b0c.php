<?php $__env->startSection('title'); ?>
    Shipment Checkpoints
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
    <div class="row">

        <div class="col-xl-12">
            <div class="card card-sec m-b-30">
                <div class="card-body">

                    <?php echo $__env->make('includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <h4 class="mt-0 m-b-15 header-title">Shipment Checkpoints</h4>
                    <p><strong>Shipment Details</strong></p>
                    <p>
                        <strong>Trackng ID:</strong> <?php echo e($shipment->tracking_id); ?><br>
                        <strong>Origin:</strong> <?php echo e($shipment->origin); ?><br>
                        <strong>Destination:</strong> <?php echo e($shipment->destination); ?><br>
                    </p>

                    <div class="table-responsive">
                        <table class="table table-hover mb-0 table-sm">
                            <thead>
                            <tr class="titles">
                                <th>S/N</th>
                                <th>Current Location</th>
                                <th>Status</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                            </thead>

                            <tbody>
                            <?php $__currentLoopData = $checkpoints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $check): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="c-table__cell"> <?php echo e($loop->iteration); ?> </td>
                                    <td class="c-table__cell"> <?php echo e($check->location); ?> </td>
                                    <td class="c-table__cell"> <?php echo e($check->status); ?> </td>
                                    <td class="c-table__cell"><?php echo e(date('jS \of F Y', strtotime($check->created_at))); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('shipment-history.edit', $check->id)); ?>">
                                            <button class="btn btn-sm btn-warning">
                                                Edit
                                            </button>
                                        </a>

                                        <form method="POST" action="<?php echo e(route('shipment-history.destroy', $check->id)); ?>" style="margin-bottom: 5px;">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="_method" value="DELETE">
                                            <button type="submit" class="btn btn-danger btn-sm">
                                                Delete
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <?php echo e($checkpoints->links()); ?>


                </div>
            </div>
        </div>

    </div>
    <!-- end row -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.controlpanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\softlinkexpress\resources\views/controlpanel/shipments/shipment-checkpoints.blade.php ENDPATH**/ ?>