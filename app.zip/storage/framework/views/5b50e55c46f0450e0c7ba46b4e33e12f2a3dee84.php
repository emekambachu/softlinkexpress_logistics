<?php $__env->startSection('title'); ?>
    All Users
<?php $__env->stopSection(); ?>


<?php $__env->startSection('contents'); ?>
    <div class="row">

        <div class="col-xl-12">
            <div class="card card-sec m-b-30">
                <div class="card-body">

                    <?php echo $__env->make('includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <h4 class="mt-0 m-b-15 header-title">Users</h4>

                    <div class="table-responsive">
                        <table class="table table-hover mb-0 table-sm">
                            <thead>
                            <tr class="titles">
                                <th>S/N</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Mobile</th>
                                <th>Country</th>
                                <th>State</th>
                                <th>Address</th>
                                <th>Action</th>
                            </tr>
                            </thead>

                            <tbody>
                            <?php if(!empty($users)): ?>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr>
                                        <td class="c-table__cell"> <?php echo e($loop->iteration); ?> </td>
                                        <td class="c-table__cell"> <?php echo e($user->name); ?> </td>
                                        <td class="c-table__cell"> <?php echo e($user->email); ?> </td>
                                        <td class="c-table__cell"> <?php echo e($user->mobile); ?> </td>
                                        <td class="c-table__cell"> <?php echo e($user->country); ?> </td>
                                        <td class="c-table__cell"> <?php echo e($user->state); ?> </td>
                                        <td class="c-table__cell"> <?php echo e($user->address); ?> </td>
                                        <td>
                                            <form method="POST" action="<?php echo e(route('users.destroy', $user->id)); ?>" style="margin-bottom: 5px;">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="_method" value="DELETE">
                                                <button type="submit" class="btn btn-warning btn-sm">
                                                    Delete
                                                </button>
                                            </form>
                                        </td>
                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <?php echo e($users->links()); ?>


                </div>
            </div>
        </div>

    </div>
    <!-- end row -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.controlpanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\softlinkexpress\resources\views/controlpanel/users/index.blade.php ENDPATH**/ ?>