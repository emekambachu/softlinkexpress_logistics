<?php $__env->startSection('title'); ?>
    Shipment History
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <header id="header" class="header header-transparent">
        <nav class="navbar navbar-expand-lg">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <img src="<?php echo e(asset('softlinkexpress_logo.png')); ?>" width="200" class="logo-light" alt="logo">
                    <img src="<?php echo e(asset('softlinkexpress_logo.png')); ?>" width="200" class="logo-dark" alt="logo">
                </a>
                <button class="navbar-toggler" type="button">
                    <span class="menu-lines"><span></span></span>
                </button>

                <div class="header__top-right d-none d-lg-block">
                    <ul class="list-unstyled d-flex justify-content-end align-items-center">
                        <li><i class="icon-phone"></i><span>+1 305-307-1470</span></li>
                        <li><i class="icon-phone"></i><span>+44 7520647634</span></li>
                        <li>
                            <div class="dropdown bg-white">
                                <div id="google_translate_element"></div>
                            </div>
                        </li>
                        <li>
                            <a href="<?php echo e(url('track-shipment')); ?>" class="btn btn__primary btn__hover3"><i class="icon-list"></i>
                                <span>Track Shipment</span></a>
                        </li>
                    </ul>
                </div><!-- /.header-top-right -->

                <div class="collapse navbar-collapse" id="mainNavigation">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav__item">
                            <a href="<?php echo e(url('/')); ?>" class="nav__item-link">Home</a>
                        </li><!-- /.nav-item -->

                        <li class="nav__item">
                            <a href="<?php echo e(url('about')); ?>" class="nav__item-link">About</a>
                        </li><!-- /.nav-item -->

                        <li class="nav__item">
                            <a href="<?php echo e(url('services')); ?>" class="nav__item-link">Services</a>
                        </li><!-- /.nav-item -->

                        <li class="nav__item">
                            <a href="<?php echo e(url('signup')); ?>" class="nav__item-link">Sign up</a>
                        </li><!-- /.nav-item -->

                        <li class="nav__item">
                            <a href="<?php echo e(url('track-shipment')); ?>" class="nav__item-link">Track Shipment</a>
                        </li><!-- /.nav-item -->

                        <li class="nav__item">
                            <a href="<?php echo e(url('contact')); ?>" class="nav__item-link">Contact Us</a>
                        </li><!-- /.nav-item -->

                    </ul><!-- /.navbar-nav -->
                </div><!-- /.navbar-collapse -->

            </div><!-- /.container -->
        </nav><!-- /.navabr -->
    </header>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
    <!-- ========================
       page title
    =========================== -->
    <section id="page-title" class="page-title bg-overlay bg-parallax" style="padding: 150px 0;">
        <div class="bg-img"><img src="<?php echo e(asset('assets/images/page-titles/13.jpg')); ?>" alt="background"></div>
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-md-12 col-lg-12">
                    <h5 class="pagetitle__heading">Shipment History</h5>
                </div><!-- /.col-lg-12 -->
            </div><!-- /.row -->
        </div><!-- /.container -->
    </section><!-- /.page-title -->

    <section id="trackShipmeent" class="track-shipmeent" style="padding: 20px 0;">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-md-12 col-lg-12">

                    <table class="table table-dark">
                        <tbody>
                        <tr>
                            <td><strong>Recipient Name:</strong> <?php echo e($shipment->user->name); ?> </td>
                            <td><strong>Recipient Email:</strong> <?php echo e($shipment->user->email); ?></td>
                            <td><strong>Recipient Mobile:</strong> <?php echo e($shipment->user->mobile); ?></td>
                        </tr>
                        <tr>
                            <td><strong>Parcel Name:</strong> <?php echo e($shipment->parcel->name); ?> </td>
                            <td><strong>Parcel Weight:</strong> <?php echo e($shipment->parcel->weight); ?></td>
                            <td><strong>Parcel Description:</strong> <?php echo e($shipment->parcel->description); ?></td>
                        </tr>
                        <tr>
                            <td><strong>Tracking ID:</strong> <?php echo e($shipment->tracking_id); ?></td>
                            <td><strong>Shipment Origin:</strong> <?php echo e($shipment->origin); ?></td>
                            <td><strong>Shipment Destination:</strong> <?php echo e($shipment->destination); ?></td>
                        </tr>
                        <tr>
                            <td><strong>Shipment Date:</strong> <?php echo e(date('jS \of F Y', strtotime($shipment->created_at))); ?></td>
                            <td><strong>Last Shipment Date:</strong>
                                <?php if(!empty($lastCheckpoint->created_at)): ?>
                                <?php echo e(date('jS \of F Y', strtotime($lastCheckpoint->created_at))); ?>

                                <?php else: ?>
                                    <i>Awaiting Shipment</i>
                                <?php endif; ?>
                            </td>
                            <td><strong>Last Location:</strong>
                                <?php if(!empty($lastCheckpoint->location)): ?>
                                    <?php echo e($lastCheckpoint->location); ?>

                                <?php else: ?>
                                   <i>Awaiting Shipment</i>
                                <?php endif; ?>
                            </td>
                        </tr>
                        </tbody>
                    </table>

                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Status</th>
                            <th scope="col">Location</th>
                            <th scope="col">Date</th>
                        </tr>
                        </thead>
                        <tbody>

                        <?php if($checkpoints): ?>
                            <?php $__currentLoopData = $checkpoints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $checkpoint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                                    <td><?php echo e($checkpoint->status); ?></td>
                                    <td><?php echo e($checkpoint->location); ?></td>
                                    <td><?php echo e(date('jS \of F Y', strtotime($checkpoint->created_at))); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <p>Awaiting Shipment</p>
                        <?php endif; ?>
                        </tbody>
                    </table>


                </div><!-- /.col-lg-8 -->

            </div><!-- /.row -->
        </div><!-- /.container -->
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\softlinkexpress\resources\views/shipment-history.blade.php ENDPATH**/ ?>