<img src="<?php echo e(asset('softlinkexpress_logo.png')); ?>" width="120">

<h3>Hello <?php echo e($name); ?></h3>

<p>Your Shipment has been initialized<br>
    Below is your tracking code<br>
    <strong><?php echo e($tracking_id); ?></strong><br><br>

    Use this code to track your shipment <a href="<?php echo e(url('track-shipment')); ?>"><strong>here</strong></a>
</p><br><br>

<p align="center">
    For more info, contact <i>info@softlinkexpress.com</i>
</p>
<?php /**PATH C:\wamp64\www\softlinkexpress\resources\views/emails/new-shipment.blade.php ENDPATH**/ ?>