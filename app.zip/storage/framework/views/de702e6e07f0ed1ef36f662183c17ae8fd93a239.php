<?php $__env->startSection('title'); ?>
    Contact us
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
    <section id="page-title" class="page-title bg-overlay bg-parallax bg-img" style="background-image: url(&quot;<?php echo e(asset('assets/images/page-titles/1.jpg')); ?>&quot;); background-size: cover; background-position: center center;">

        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-md-12 col-lg-12">
                    <h1 class="pagetitle__heading">Contact Us</h1>
                </div><!-- /.col-lg-12 -->
            </div><!-- /.row -->
        </div><!-- /.container -->
    </section>

    <section id="contact1" class="contact text-center">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-md-12 col-lg-6 offset-lg-3">
                    <div class="heading text-center mb-50">
                        <span class="heading__subtitle">Get In Touch</span>
                        <h2 class="heading__title">Contact Us</h2>
                        <div class="divider__line divider__theme divider__center mb-0"></div>
                        <p class="heading__desc">We understand the importance of approaching each work integrally and believe in
                            the power of simple and easy communication.</p>
                    </div><!-- /.heading -->
                </div><!-- /.col-lg-6 -->
            </div><!-- /.row -->
            <div class="row">
                <div class="col-sm-12 col-md-12 col-lg-8 offset-lg-2">
                    <form>
                        <div class="row">
                            <div class="col-sm-6 col-md-6 col-lg-6">
                                <div class="form-group"><input type="text" class="form-control" placeholder="Name"></div>
                            </div><!-- /.col-lg-6 -->
                            <div class="col-sm-6 col-md-6 col-lg-6">
                                <div class="form-group"><input type="email" class="form-control" placeholder="Email"></div>
                            </div><!-- /.col-lg-6 -->
                        </div><!-- /.row -->
                        <div class="row">
                            <div class="col-sm-6 col-md-6 col-lg-6">
                                <div class="form-group"><input type="text" class="form-control" placeholder="Phone"></div>
                            </div><!-- /.col-lg-6 -->
                            <div class="col-sm-6 col-md-6 col-lg-6">
                                <div class="form-group"><input type="text" class="form-control" placeholder="Company"></div>
                            </div><!-- /.col-lg-6 -->
                        </div><!-- /.row -->
                        <div class="row">
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="form-group">
                                    <textarea class="form-control" placeholder="Request Details"></textarea>
                                </div>
                            </div><!-- /.col-lg-12 -->
                        </div><!-- /.row -->
                        <div class="row">
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <button type="submit" class="btn btn__secondary btn__hover3">Submit Request</button>
                            </div><!-- /.col-lg-12 -->
                        </div><!-- /.row -->
                    </form>
                </div><!-- /.col-lg-8 -->
            </div><!-- /.row -->
        </div><!-- /.container -->
    </section>

    <!-- =========================
            Google Map
    =========================  -->
    <section id="googleMap" class="google-map p-0">
        <div id="map"></div>
        <script src="<?php echo e(asset('assets/js/google-map.js')); ?>"></script>
        <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCqrqPZOVegy1VIdyIcndxZY9YGoK-x0Yo&amp;callback=initMap"
                async defer></script>
    </section><!-- /.GoogleMap -->

    <!-- ==========================
       Contact panels
    ============================ -->
    <section id="contactPanels" class="contact-panels text-center pb-70">
        <div class="container">
            <div class="row">

                <!-- Contact panel #1 -->
                <div class="col-sm-12 col-md-12 col-lg-4">
                    <div class="contact-panel">
                        <div class="contact__panel-header">
                            <h4 class="contact__panel-title">London Office</h4>
                        </div>
                        <ul class="contact__list list-unstyled">
                            <li>002 010123456789</li>
                            <li>Email: Softlink Express Delivery@7oroof.com</li>
                            <li>Address: 2307 Beverley Rd Brooklyn, NY</li>
                            <li>Hours: Mon-Fri: 8am – 7pm</li>
                        </ul>
                        <a href="#" class="btn btn__primary btn__hover3">Read More</a>
                    </div><!-- /.contact-panel -->
                </div><!-- /.col-lg-4 -->

                <!-- Contact panel #2 -->
                <div class="col-sm-12 col-md-12 col-lg-4">
                    <div class="contact-panel">
                        <div class="contact__panel-header">
                            <h4 class="contact__panel-title">Berlin Office</h4>
                        </div>
                        <ul class="contact__list list-unstyled">
                            <li>002 010123456789</li>
                            <li>Email: Softlink Express Delivery@7oroof.com</li>
                            <li>Address: 2307 Beverley Rd Brooklyn, NY</li>
                            <li>Hours: Mon-Fri: 8am – 7pm</li>
                        </ul>
                        <a href="#" class="btn btn__primary btn__hover3">Read More</a>
                    </div><!-- /.contact-panel -->
                </div><!-- /.col-lg-4 -->

                <!-- Contact panel #3 -->
                <div class="col-sm-12 col-md-12 col-lg-4">
                    <div class="contact-panel">
                        <div class="contact__panel-header">
                            <h4 class="contact__panel-title">Manchester Office</h4>
                        </div>
                        <ul class="contact__list list-unstyled">
                            <li>002 010123456789</li>
                            <li>Email: Softlink Express Delivery@7oroof.com</li>
                            <li>Address: 2307 Beverley Rd Brooklyn, NY</li>
                            <li>Hours: Mon-Fri: 8am – 7pm</li>
                        </ul>
                        <a href="#" class="btn btn__primary btn__hover3">Read More</a>
                    </div><!-- /.contact-panel -->
                </div><!-- /.col-lg-4 -->

            </div><!-- /.row -->
        </div><!-- /.container -->
    </section><!-- /. Contact panels -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\cargobaselogistics\resources\views/contact.blade.php ENDPATH**/ ?>
