<img src="<?php echo e(asset('softlinkexpress_logo.png')); ?>" width="120">

<h3><?php echo e($name); ?> Has Signed up</h3>

<p>User Details:<br>
    <strong>Name:</strong> <?php echo e($name); ?><br>
    <strong>Email:</strong> <?php echo e($email); ?><br>
    <strong>Mobile:</strong> <?php echo e($mobile); ?><br>
    <strong>Country:</strong> <?php echo e($country); ?><br>
    <strong>State:</strong> <?php echo e($state); ?><br>
    <strong>Address:</strong> <?php echo e($address); ?><br>
</p>
<?php /**PATH C:\wamp64\www\softlinkexpress\resources\views/emails/new-signup-admin.blade.php ENDPATH**/ ?>
