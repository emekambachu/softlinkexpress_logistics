<img src="<?php echo e(asset('softlinkexpress_logo.png')); ?>" width="120">

<h3>Hello <?php echo e($name); ?></h3>

<p>Your Shipment Details are as follows:<br>
    <strong>Parcel Name:</strong> <?php echo e($parcel); ?><br>
    <strong>Tracking ID:</strong> <?php echo e($tracking_id); ?><br>
</p>

<p>
    Your shipment will be approved in the next 12 hours<br>
    Once approved, go to link to <a href="<?php echo e(url('track-shipment')); ?>"><strong>Track Parcel</strong></a>
</p>
<?php /**PATH C:\wamp64\www\cargobaselogistics\resources\views/emails/new-signup.blade.php ENDPATH**/ ?>
