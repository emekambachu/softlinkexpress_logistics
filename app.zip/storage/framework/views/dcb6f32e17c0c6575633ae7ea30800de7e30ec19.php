<?php $__env->startSection('title'); ?>
    Add Parcel
<?php $__env->stopSection(); ?>


<?php $__env->startSection('contents'); ?>
    <div class="row">

        <div class="col-sm-6 text-left p-5">

            <?php echo $__env->make('includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <h3>Add Parcel</h3>
            <form method="post" action="<?php echo e(route('parcels.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label>Parcel Name</label>
                    <input name="name" class="form-control" type="text" placeholder="Parcel Name" required>
                </div>

                <div class="form-group">
                    <label>Parcel Weight</label>
                    <input name="weight" class="form-control" type="number" placeholder="Parcel KG" required>
                </div>

                <div class="form-group">
                    <label>Parcel Description</label>
                    <textarea name="description" class="form-control"></textarea>
                </div>

                <button type="submit" class="btn btn-primary">Submit</button>
            </form>


        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.controlpanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\softlinkexpress\resources\views/controlpanel/parcels/create.blade.php ENDPATH**/ ?>