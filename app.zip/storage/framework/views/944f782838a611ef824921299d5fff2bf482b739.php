<?php $__env->startSection('title'); ?>
    Edit Shipment
<?php $__env->stopSection(); ?>


<?php $__env->startSection('contents'); ?>
    <div class="row">

        <div class="col-sm-6 text-left p-5">

            <?php echo $__env->make('includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <h3>Edit this shipment</h3>
            <form method="post" action="<?php echo e(route('shipments.update', $shipment->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="form-group">
                    <label>Origin</label>
                    <input name="origin" class="form-control" type="text"
                           value="<?php echo e($shipment->origin); ?>" required>
                </div>

                <div class="form-group">
                    <label>Final Destination</label>
                    <input name="destination" class="form-control" type="text"
                           value="<?php echo e($shipment->destination); ?>" required>
                </div>

                <button type="submit" class="btn btn-primary">Update</button>
            </form>


        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.controlpanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\softlinkexpress\resources\views/controlpanel/shipments/edit.blade.php ENDPATH**/ ?>