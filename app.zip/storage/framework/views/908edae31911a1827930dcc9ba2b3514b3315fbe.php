<?php $__env->startSection('title'); ?>
    Edit Checkpoint
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
    <div class="row">

        <div class="col-sm-6 text-left p-5">

            <?php echo $__env->make('includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <h3>Edit Checkpoint</h3>
            <form method="post" action="<?php echo e(route('shipment-history.update', $checkpoint->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="form-group">
                    <label>Current Location</label>
                    <input name="location" class="form-control" type="text"
                           value="<?php echo e($checkpoint->location); ?>" required>
                </div>

                <div class="form-group">
                    <label>Status</label>
                    <textarea class="form-control" name="status" required>
                            <?php echo e($checkpoint->status); ?>

                    </textarea>
                </div>

                <button type="submit" class="btn btn-primary">Update</button>
            </form>


        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.controlpanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\softlinkexpress\resources\views/controlpanel/shipments/edit-checkpoint.blade.php ENDPATH**/ ?>