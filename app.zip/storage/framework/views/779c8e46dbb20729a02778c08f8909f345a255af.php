<?php $__env->startSection('title'); ?>
    Create Shipment
<?php $__env->stopSection(); ?>


<?php $__env->startSection('contents'); ?>
    <div class="row">
        <div class="col-sm-6 text-left p-5">

            <?php echo $__env->make('includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <h3>Create Shipments</h3>
            <p>create shipments from user and parcel info</p>
            <form method="post" action="<?php echo e(route('shipments.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label>User</label>
                    <select class="form-control" name="user_id" required>
                        <option selected>Select User</option>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group">
                    <label>Parcel</label>
                    <select class="form-control" name="parcel_id" required>
                        <option selected>Select Parcel</option>
                        <?php $__currentLoopData = $parcels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parcel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($parcel->id); ?>"><?php echo e($parcel->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group">
                    <label>Origin</label>
                    <input name="origin" class="form-control" type="text" placeholder="Shipment Origin" required>
                </div>

                <div class="form-group">
                    <label>Destination</label>
                    <input name="destination" class="form-control" type="text" placeholder="Shipment Destination" required>
                </div>

                <button type="submit" class="btn btn-primary">Submit</button>
            </form>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.controlpanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\softlinkexpress\resources\views/controlpanel/shipments/create.blade.php ENDPATH**/ ?>