<!doctype html>
<html>
<head>
    <title><?php echo e($shipment->tracking_id); ?> - Softlink Express Delivery</title>

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="keywords" content="" />
    <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
    <link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
    <link href="<?php echo e(asset('tracking/css/style.css')); ?>" rel="stylesheet" type="text/css" media="all" />
</head>
<body>

<div class="header">
    <h1>Shipment Track</h1>
</div>

<div class="content">
    <div class="content1">
        <h2>Shipment Tracking: <?php echo e($shipment->tracking_id); ?></h2>
    </div>
    <div class="content2">
        <div class="content2-header1">
            <p>Origin : <span><?php echo e($shipment->origin); ?></span></p>
        </div>
        <div class="content2-header1">
            <p>Status : <span><?php echo e($shipment->destination); ?></span></p>
        </div>
        <div class="content2-header1">
            <p>Date Started : <span><?php echo e(date('jS \of F Y', strtotime($shipment->created_at))); ?></span></p>
        </div>
        <div class="clear"></div>
    </div>
    <div class="content3">
        <div class="shipment">

            <div class="confirm">
                <div class="stop1" style="background-color: #98D091;">
                    <img src="<?php echo e(asset('tracking/images/confirm.png')); ?>" alt="confirm order">
                </div>
                <span class="line"></span>
                <p><strong>Shipped</strong></p>
            </div>

            <?php if(!empty($shipment->stop1)): ?>
            <div class="quality">
                <div class="stop1" style="background-color: #98D091;">
                    <img src="<?php echo e(asset('tracking/images/dispatch.png')); ?>" alt="quality check">
                </div>
                <span class="line"></span>
                <p><?php echo e($shipment->stop1); ?></p>
            </div>
            <?php else: ?>
            <div class="quality">
                <div class="stop1" style="background-color: #F5998E;">
                    <img src="<?php echo e(asset('tracking/images/dispatch.png')); ?>" alt="quality check">
                </div>
                <span class="line"></span>
                <p>Next Stop</p>
            </div>
            <?php endif; ?>

            <?php if(!empty($shipment->stop2)): ?>
                <div class="quality">
                    <div class="stop1" style="background-color: #98D091;">
                        <img src="<?php echo e(asset('tracking/images/dispatch.png')); ?>" alt="quality check">
                    </div>
                    <span class="line"></span>
                    <p><?php echo e($shipment->stop2); ?></p>
                </div>
            <?php else: ?>
                <div class="quality">
                    <div class="stop1" style="background-color: #F5998E;">
                        <img src="<?php echo e(asset('tracking/images/dispatch.png')); ?>" alt="quality check">
                    </div>
                    <span class="line"></span>
                    <p>Next Stop</p>
                </div>
            <?php endif; ?>

            <?php if(!empty($shipment->stop3)): ?>
                <div class="quality">
                    <div class="stop1" style="background-color: #98D091;">
                        <img src="<?php echo e(asset('tracking/images/dispatch.png')); ?>" alt="quality check">
                    </div>
                    <span class="line"></span>
                    <p><?php echo e($shipment->stop3); ?></p>
                </div>
            <?php else: ?>
                <div class="quality">
                    <div class="stop1" style="background-color: #F5998E;">
                        <img src="<?php echo e(asset('tracking/images/dispatch.png')); ?>" alt="quality check">
                    </div>
                    <span class="line"></span>
                    <p>Next Stop</p>
                </div>
            <?php endif; ?>

            <div class="delivery">
                <div class="imgcircle">
                    <img src="<?php echo e(asset('tracking/images/delivery.png')); ?>" alt="delivery">
                </div>
                <p>Product Delivered</p>
            </div>

            <div class="clear"></div>
        </div>
    </div>
</div>

<div class="footer">
    <p>Copyright <?php echo e(date('Y')); ?> © Softlink Express Delivery.</p>
</div>
</body>
</html>
<?php /**PATH C:\wamp64\www\cargobaselogistics\resources\views/shipment-history.blade.php ENDPATH**/ ?>
