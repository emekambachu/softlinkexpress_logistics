<img src="<?php echo e(asset('softlinkexpress_logo.png')); ?>" width="100">

<h3>Dear <?php echo e($name); ?>,</h3>

<?php if($status): ?>
    <p>
        <strong>Your Shipment has been activated.</strong><br>
        <strong>Tracking ID:</strong> <?php echo e($tracking_id); ?>

    </p>
    <p>go to our <a href="<?php echo e(url('track-shipment')); ?>"><strong>Track Shipment Page</strong></a> to track your parcel</p>
<?php else: ?>
    <p>
        <strong>Your Shipment has been deactivated.</strong><br>
    </p>
<?php endif; ?>

<p>contact <i>info@softlinkexpress.com</i> for more info.</p>
<?php /**PATH C:\wamp64\www\cargobaselogistics\resources\views/emails/verify-shipment.blade.php ENDPATH**/ ?>
