<img src="<?php echo e(asset('softlinkexpress_logo.png')); ?>" width="120">

<h3>Hello <?php echo e($name); ?></h3>
<h4>Tracking ID: <?php echo e($tracking_id); ?></h4><br>

<p>Your Parcel just arrived at <?php echo e($location); ?><br>
    <strong>Tracking ID:</strong> <?php echo e($tracking_id); ?> <br><br>

    Track your shipment here <a href="<?php echo e(url('track-shipment')); ?>"><strong>here</strong></a>
</p><br><br>

<p align="center">
    For more info, contact <i>info@softlinkexpress.com</i>
</p>
<?php /**PATH C:\wamp64\www\softlinkexpress\resources\views/emails/new-checkpoint.blade.php ENDPATH**/ ?>