<?php $__env->startSection('title'); ?>
    Get Tracking Code
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>

    <section id="page-title" class="page-title bg-overlay bg-parallax bg-img" style="background-image: url(&quot;<?php echo e(asset('assets/images/page-titles/14.jpg')); ?>&quot;); background-size: cover; background-position: center center;">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-md-12 col-lg-12">
                    <h1 class="pagetitle__heading">Get Tracking ID</h1>
                </div><!-- /.col-lg-12 -->
            </div><!-- /.row -->
        </div><!-- /.container -->
    </section>

    <section id="trackShipmeent" class="track-shipmeent">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-md-12 col-lg-4">
                    <aside class="sidebar sidebar-layout2 mb-30">
                        <div class="widget widget-categories widget-categories-2">
                            <div class="widget-content">
                                <ul class="list-unstyled">
                                    <li><a href="">Warehousing</a></li>
                                    <li><a href="">Air Freight</a></li>
                                    <li><a href="">Ocean Freight</a></li>
                                    <li><a href="">Road Freight</a></li>
                                    <li><a href="">Supply Chain</a></li>
                                    <li><a href="">Packaging</a></li>
                                </ul>
                            </div><!-- /.widget-content -->
                        </div><!-- /.widget-categories -->

                        <div class="widget widget-help bg-theme">
                            <div class="widget__content">
                                <h5>How Can <br> We Help You!</h5>
                                <p>We understand the importance approaching each work integrally and believe in the power of simple
                                    and easy communication.</p>
                                <a href="<?php echo e(url('contact')); ?>" class="btn btn__secondary btn__hover2"><i class="fa fa-envelope"></i>Contact Us</a>
                            </div><!-- /.widget-download -->
                        </div><!-- /.widget-help -->

                    </aside><!-- /.sidebar -->
                </div><!-- /.col-lg-4 -->

                <div class="col-sm-12 col-md-12 col-lg-8">

                    <?php echo $__env->make('includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <form method="post" action="<?php echo e(route('shipments.store')); ?>" class="request-quote-form">
                        <?php echo csrf_field(); ?>
                        <div class="row mb-30">
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <p class="fz-16 mb-45">Get your Tracking number to track your shipment.</p>
                            </div><!-- /.col-lg-12 -->

                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="form-group">
                                    <label>Parcel Number</label>
                                    <div class="form-group">
                                        <input type="text" name="parcel_number" class="form-control" placeholder="Parcel Number">
                                    </div>
                                </div>
                            </div><!-- /.col-lg-12 -->

                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="form-group">
                                    <label>Name</label>
                                    <div class="form-group">
                                        <input type="text" name="name" class="form-control" placeholder="Your Name">
                                    </div>
                                </div>
                            </div><!-- /.col-lg-12 -->

                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="form-group">
                                    <label>Email</label>
                                    <div class="form-group">
                                        <input type="email" name="email" class="form-control" placeholder="Your Email">
                                    </div>
                                </div>
                            </div><!-- /.col-lg-12 -->

                        </div><!-- /.row -->
                        <div class="row">
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <button type="submit" class="btn btn__secondary btn__block">Get Tracking ID</button>
                            </div><!-- /.col-lg-12 -->
                        </div><!-- /.row -->
                    </form>
                </div><!-- /.col-lg-8 -->

            </div><!-- /.row -->
        </div><!-- /.container -->
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\cargobaselogistics\resources\views/signup.blade.php ENDPATH**/ ?>
