<img src="<?php echo e(asset('softlinkexpress_logo.png')); ?>" width="120">

<h3><?php echo e($name); ?> has initiated a Shipment</h3>

<p>Shipment Details are as follows:<br>
    <strong>Parcel Name:</strong> <?php echo e($parcel); ?><br>
    <strong>Tracking ID:</strong> <?php echo e($tracking_id); ?><br>
</p>

<p>
    Go to the <a href="<?php echo e(url('control-panel/shipments')); ?>"></a> control panel,<br>
    Fill in the shipment details,<br>
    Then Approve the shipment for the user to track
</p>
<?php /**PATH C:\wamp64\www\cargobaselogistics\resources\views/emails/new-signup-admin.blade.php ENDPATH**/ ?>
